from pathlib import Path
import sys,json
from scripts.render_terrain_preview84 import encode
root=Path(sys.argv[1])
dest=root/'encode_check'; dest.mkdir(exist_ok=False)
source=root/'media'
baseline=json.loads((source/'render_report.json').read_text())
for pair in baseline['pairs'].values():
    (dest/pair['png_directory']).symlink_to(source/pair['png_directory'],target_is_directory=True)
result=encode(dest,baseline['pairs'])
with (dest/'report.json').open('x') as f: json.dump({'files':result,'original_media_sha_identical':{k:v['sha256']==baseline['media'][k]['sha256'] for k,v in result.items()}},f,indent=2)
