"""Packaged MuJoCo assets."""
